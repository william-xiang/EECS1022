package ca.com.william.pingpong;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * The model of PingPong app.
 *
 * @author Hengchao Xiang
 * Created by user on 6/24/17.
 */
public class PPModel
{
    private boolean indicator;  //false is Ping, true is Pong.

    /**
     * Initializes this PingPong model.
     */
    public PPModel()
    {
        this.indicator = true;
    }

    /**
     * Returns Ping and Pong,alternatively.
     * @return Ping or Pong.
     */
    public String swapPP()
    {
        indicator = !indicator;

        if(indicator)
        {
            return "Ping";
        }
        else
        {
            return "Pong";
        }
    }

    /**
     * Returns a random integer array resembling a color
     * @return an integer array resembling a color
     */
    public String Color()
    {
        String red = Integer.toHexString((ThreadLocalRandom.current().nextInt(0, 256)) | 0x100).substring(1);
        String green = Integer.toHexString((ThreadLocalRandom.current().nextInt(0, 256)) | 0x100).substring(1);
        String blue = Integer.toHexString((ThreadLocalRandom.current().nextInt(0, 256)) | 0x100).substring(1);

        return "#" + red + green + blue;
    }

    public static void main(String[] args) {
        PPModel model = new PPModel();
        System.out.println(model.Color());
    }
}
