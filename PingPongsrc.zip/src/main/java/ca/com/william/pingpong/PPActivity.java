package ca.com.william.pingpong;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

/**
 * The controller of PingPong app.
 *
 * @author Hengchao Xiang
 */
public class PPActivity extends AppCompatActivity
{
    private PPModel pp;

    /**
     * Initializes the controller.
     *
     * @param savedInstanceState information needed for re-initialization.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pp);
        this.pp = new PPModel();
    }

    /**
     * Sets the text to either Ping or Pong.
     *
     * @param view not applicable
     */
    public void buttonClicked(View view)
    {
        TextView textView = (TextView)findViewById(R.id.ppView);
        textView.setText(pp.swapPP());
        textView.setTextColor(Color.parseColor(pp.Color()));
    }
}
