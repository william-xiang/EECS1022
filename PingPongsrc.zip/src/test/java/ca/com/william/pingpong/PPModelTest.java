package ca.com.william.pingpong;

import org.junit.Test;
import static org.junit.Assert.*;

public class PPModelTest
{
    @Test
    public void constructorTest()
    {
        PPModel model = new PPModel();
    }

    @Test
    public void swapPPTest()
    {
        PPModel model = new PPModel();
        assertEquals("Ping", "Ping");
    }
}
