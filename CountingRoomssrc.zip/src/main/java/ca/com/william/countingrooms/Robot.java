package ca.com.william.countingrooms;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Created by user on 6/30/17.
 */
public class Robot
{
    public static int coordX; //the x-coordinate of robot
    public static int coordY; //the y-coordinate of robot

    public Robot()
    {
        coordX = ThreadLocalRandom.current().nextInt(Map.mapHeight);

        if(coordX >= Map.height)
        {
            coordY = ThreadLocalRandom.current().nextInt(Map.mapWidth);
        }
        else
        {
            coordY = ThreadLocalRandom.current().nextInt(Map.width);
        }
    }
}
