package ca.com.william.countingrooms;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.widget.ImageView;
import android.widget.LinearLayout;

/**
 * Created by William on 6/30/2017.
 */
public class Grid {
    public static BitmapDrawable bitmapDrawable;
    private static int graphic[][];
    private static int cellX;
    private static int cellY;
    private static int cellSize;
    public static float border;
    public static float left;
    public static Paint paint;
    public static Canvas canvas;
    public static Bitmap bitmap;
    public static int sizeLayout;
    private static ImageView robot;
    private Resources res;
    private Resources.Theme theme;

    public Grid(int sizeLayout, Context context)
    {
        graphic = Map.map;
        cellX = graphic.length;  //number of rows
        cellY = graphic[0].length;  //number of columns
        Grid.sizeLayout = sizeLayout;
        res = context.getResources();
        theme = context.getTheme();

        cellSize = (cellX > cellY) ? cellSize(cellX, sizeLayout) : cellSize(cellY, sizeLayout);
        border = (int) Math.round(cellSize * 0.1);
        left = (sizeLayout - cellSize * cellY) / 2;

        bitmap = Bitmap.createBitmap(sizeLayout, sizeLayout, Bitmap.Config.ARGB_8888);  //create a Bitmap object
        paint = new Paint();  //create a new Paint object
        canvas = new Canvas(bitmap);   //create a canvas to hold all the draws

        draw();

        bitmapDrawable = new BitmapDrawable(res, bitmap);
    }

    public static void draw()
    {
        for(int x = 0; x < graphic.length; x++)   //x is for rows, y is for columns
            for (int y = 0; y < graphic[x].length; y++)
            {
                drawCells(x, y, cellX > cellY);
                drawBorder(x, y, cellX > cellY);
            }

        for(int x = 0; x < graphic.length; x++)   //x is for rows, y is for columns
            for (int y = 0; y < graphic[x].length; y++)
            {
                drawDoor(x, y, cellX > cellY);
            }

    }

    public void clear()
    {
        canvas.drawColor(0, PorterDuff.Mode.CLEAR);
        bitmapDrawable = new BitmapDrawable(res, bitmap);
    }

    public int cellSize(int cellNum, int dim)
    {
        return (int)Math.round(dim/cellNum);
    }

    public static void drawCells(int x, int y, boolean xORy)
    {
        if(xORy)
        {
            if(graphic[x][y] == 1) //
            {
                //draw a rectangle on Bitmap, here the dimensions are relative to the view
                //draw the center of the cells
                paint.setColor(Color.LTGRAY);
                canvas.drawRect(left + y * cellSize, x * cellSize, left + (y + 1) * cellSize, (x + 1) * cellSize, paint);
            }
            else if(graphic[x][y] == 2)
            {
                paint.setColor(Color.YELLOW);
                canvas.drawRect(left + y * cellSize, x * cellSize, left + (y + 1) * cellSize, (x + 1) * cellSize, paint);
            }
            else
            {
                paint.setColor(Color.BLACK);
                canvas.drawRect(left + y * cellSize, x * cellSize, left + (y + 1) * cellSize, (x + 1) * cellSize, paint);
            }
        }
        else
        {
            if(graphic[x][y] == 1)
            {
                paint.setColor(Color.LTGRAY);
                canvas.drawRect(y * cellSize, x * cellSize, (y + 1) * cellSize, (x + 1) * cellSize, paint);
            }
            else if(graphic[x][y] == 2)
            {
                paint.setColor(Color.YELLOW);
                canvas.drawRect(y * cellSize, x * cellSize, (y + 1) * cellSize, (x + 1) * cellSize, paint);
            }
            else
            {
                paint.setColor(Color.BLACK);
                canvas.drawRect(y * cellSize, x * cellSize, (y + 1) * cellSize, (x + 1) * cellSize, paint);
            }
        }
    }

    public static void drawDoor(int x, int y, boolean xORy)
    {
        paint.setColor(Color.parseColor("#333300"));

        if(southExist(x, y))
        {
            if(xORy)
            {
                canvas.drawRect(left + (y + (float)1 / 3) * cellSize, (x + 1) * cellSize - border, left + (y + (float)2 / 3) * cellSize, (x + 1) * cellSize + border, paint);
            }
            else
            {
                canvas.drawRect((y + (float)1 / 3) * cellSize, (x + 1) * cellSize - border, (y + (float)2 / 3) * cellSize, (x + 1) * cellSize + border, paint);
            }
        }

        if(eastExist(x, y))
        {
            if(xORy)
            {
                canvas.drawRect(left + (y + 1) * cellSize - border, (x + (float)1 /3) * cellSize, left + (y + 1) * cellSize + border, (x + (float)2 / 3) * cellSize, paint);
            }
            else
            {
                canvas.drawRect((y + 1) * cellSize - border, (x + (float)1 /3) * cellSize, (y + 1) * cellSize + border, (x + (float)2 / 3) * cellSize, paint);
            }
        }
    }


    /**
     * draw the north border of each cell
     * @param x
     * @param y
     * @param xORy
     */
    public static void drawBorder(int x, int y, boolean xORy)
    {
        Path path = new Path();

        if(xORy)
        {
            //draw the northern border of cells
            paint.setColor(Color.parseColor("#00FF00"));
            path.moveTo(left + y * cellSize, x * cellSize);
            path.lineTo(left + y * cellSize + border, x * cellSize + border);
            path.lineTo(left + (y + 1) * cellSize - border, x * cellSize + border);
            path.lineTo(left + (y + 1) * cellSize, x * cellSize);
            path.close();
            canvas.drawPath(path, paint);
            path.reset();

            //draw the southern border of cells
            paint.setColor(Color.parseColor("#F4A460"));
            path.moveTo(left + y * cellSize, (x + 1) * cellSize);
            path.lineTo(left + y * cellSize + border, (x + 1) * cellSize - border);
            path.lineTo(left + (y + 1) * cellSize - border, (x + 1) * cellSize - border);
            path.lineTo(left + (y + 1) * cellSize, (x + 1) * cellSize);
            path.close();
            canvas.drawPath(path, paint);
            path.reset();

            //draw the western border of cells
            paint.setColor(Color.parseColor("#800080"));
            path.moveTo(left + y * cellSize, x * cellSize);
            path.lineTo(left + y * cellSize + border, x * cellSize + border);
            path.lineTo(left + y * cellSize + border, (x + 1) * cellSize - border);
            path.lineTo(left + y * cellSize, (x + 1) * cellSize);
            path.close();
            canvas.drawPath(path, paint);
            path.reset();

            //draw the eastern border of cells
            paint.setColor(Color.parseColor("#3333FF"));
            path.moveTo(left + (y + 1) * cellSize, x * cellSize);
            path.lineTo(left + (y + 1) * cellSize - border, x * cellSize + border);
            path.lineTo(left + (y + 1) * cellSize - border, (x + 1) * cellSize - border);
            path.lineTo(left + (y + 1) * cellSize, (x + 1) * cellSize);
            path.close();
            canvas.drawPath(path, paint);
            path.reset();
        }
        else
        {
            //draw northern border of cells
            paint.setColor(Color.parseColor("#00FF00"));
            path.moveTo(y * cellSize, x * cellSize);
            path.lineTo(y * cellSize + border, x * cellSize + border);
            path.lineTo((y + 1) * cellSize - border, x * cellSize + border);
            path.lineTo((y + 1) * cellSize, x * cellSize);
            path.close();
            canvas.drawPath(path, paint);
            path.reset();

            //draw the southern border of cells
            paint.setColor(Color.parseColor("#F4A460"));
            path.moveTo(y * cellSize, (x + 1) * cellSize);
            path.lineTo(y * cellSize + border, (x + 1) * cellSize - border);
            path.lineTo((y + 1) * cellSize - border, (x + 1) * cellSize - border);
            path.lineTo((y + 1) * cellSize, (x + 1) * cellSize);
            path.close();
            canvas.drawPath(path, paint);
            path.reset();

            //draw the western border of cells
            paint.setColor(Color.parseColor("#800080"));
            path.moveTo(y * cellSize, x * cellSize);
            path.lineTo(y * cellSize + border, x * cellSize + border);
            path.lineTo(y * cellSize + border, (x + 1) * cellSize - border);
            path.lineTo(y * cellSize, (x + 1) * cellSize);
            path.close();
            canvas.drawPath(path, paint);
            path.reset();

            //draw the eastern border of cells
            paint.setColor(Color.parseColor("#3333FF"));
            path.moveTo((y + 1) * cellSize, x * cellSize);
            path.lineTo((y + 1) * cellSize - border, x * cellSize + border);
            path.lineTo((y + 1) * cellSize - border, (x + 1) * cellSize - border);
            path.lineTo((y + 1) * cellSize, (x + 1) * cellSize);
            path.close();
            canvas.drawPath(path, paint);
            path.reset();
        }
    }

    /**
     * show robot image in linearlayout
     * @param x
     * @param y
     * @param context
     * @param linearLayout
     */;
    public void showRobot(int x, int y, Context context, LinearLayout linearLayout)
    {
        if(robot != null)
        {
            removeRobot(linearLayout);
        }
        robot = new ImageView(context);
        robot.setImageResource(R.drawable.android);
        linearLayout.addView(robot);
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) robot.getLayoutParams();

        BitmapDrawable bd = (BitmapDrawable) robot.getResources().getDrawable(R.drawable.android, theme);
        int origHeight = bd.getBitmap().getHeight();
        int origWidth = bd.getBitmap().getWidth();

        params.height = (int)(cellSize * 0.6);
        params.width = (int)(origWidth * params.height / origHeight);

        float xPos = 0;
        float yPos = 0;

        if(cellX > cellY)
        {
            xPos = left + (float)((x + 0.5) * cellSize - params.width / 2.0);
            yPos = (float)((y + 0.48) * cellSize - params.height / 2.0);
        }
        else
        {
            xPos = (float)((x + 0.5) * cellSize - params.width / 2.0);
            yPos = (float)((y + 0.48) * cellSize - params.height / 2.0);
        }

        robot.setX(xPos);
        robot.setY(yPos);
    }

    public void removeRobot(LinearLayout linearLayout)
    {
        linearLayout.removeView(robot);
    }

    public static boolean southExist(int x, int y)
    {
        return x != cellX - 1 && (graphic[x + 1][y] == 1 || graphic[x + 1][y] == 2) && (graphic[x][y] == 1  || graphic[x][y] == 2);
    }

    public static boolean eastExist(int x, int y)
    {
        return y != cellY - 1 && (graphic[x][y + 1] == 1 || graphic[x][y + 1] == 2) && (graphic[x][y] == 1  || graphic[x][y] == 2);
    }
}
