package ca.com.william.countingrooms;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Created by user on 6/29/17.
 */
public class Map
{
    public static int map[][];
    public static int mapWidth;
    public static int mapHeight;
    public static int width; //the width of the room
    public static int height; //the height of the room
    public static int roomNum;

    public Map()
    {
        mapHeight = ThreadLocalRandom.current().nextInt(2, 11);  //random number from 2 to 10, for rows
        mapWidth = ThreadLocalRandom.current().nextInt(2, 11);  //random number from 2 to 10, for columns
        height = ThreadLocalRandom.current().nextInt(1, mapHeight);
        width = ThreadLocalRandom.current().nextInt(1, mapWidth);
        map = new int[mapHeight][mapWidth];

        roomNum = 0;

        for(int x = 0; x < mapHeight; x++)
            for (int y = 0; y < mapWidth; y++)
            {
                if(y < width)
                {
                    map[x][y] = 1;
                    roomNum++;
                }
                else
                {
                    if(x >= height)
                    {
                        map[x][y] = 1;
                        roomNum++;
                    }
                }
            }
    }

    public static void main(String[] args)
    {
        System.out.println("Map Width: " + Map.mapWidth + "\nMap Height: " + Map.mapHeight + "\nMiss Width: " + (Map.mapWidth - Map.width) + "\nMiss Height: " + Map.height);
        System.out.println("" + Map.roomNum);
    }
}
