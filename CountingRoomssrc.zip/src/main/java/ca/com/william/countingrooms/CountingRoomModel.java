package ca.com.william.countingrooms;

/**
 * The model of Counting Rooms app.
 *
 * @author Hengchao Xiang
 * Created by user on 6/26/17.
 */
public class CountingRoomModel
{
    private int counter; //the number of rooms
    private int score;

    /**
     * Initializes this Counting Rooms model
     */
    public CountingRoomModel()
    {
        new Map();
        new Robot();
        this.counter = 0;
        this.score = 0;

        Map.map[Robot.coordX][Robot.coordY] = 2;
    }

    public String getScore()
    {
        return String.format("%s", this.score);
    }

    public boolean compareRooms(int num)
    {
        return num == Map.roomNum;
    }

    /**
     * Shows if the robot can go north
     *
     * @return false if cannot go north, else true
     */
    public boolean canGoNorth()
    {
        if(Robot.coordY < Map.width)
        {
            return Robot.coordX > 0;
        }
        else
        {
            return Robot.coordX > Map.height;
        }
    }

    /**
     * Shows if the robot can go south
     *
     * @return false if cannot go south, else true
     */
    public boolean canGoSouth()
    {
        return Robot.coordX < (Map.mapHeight - 1);
    }

    /**
     * Shows if the robot can go west
     *
     * @return false if cannot go west, else true
     */
    public boolean canGoWest()
    {
        return Robot.coordY > 0;
    }

    /**
     * Shows if the robot can go east
     *
     * @return false if cannot go east, else true
     */
    public boolean canGoEast()
    {
        if(Robot.coordX < Map.height)
        {
            return Robot.coordY < (Map.width - 1);
        }
        else
        {
            return Robot.coordY < (Map.mapWidth - 1);
        }
    }

    /**
     * Increases the room number by 1 when north button clicked once
     */
    public void nIncrement()
    {
        this.counter++;

        if(Robot.coordY < Map.width)
        {
            if(!this.canGoNorth())
            {
                this.score++;
            }
            else
            {
                Robot.coordX--;
                Map.map[Robot.coordX][Robot.coordY] = 2;
            }
        }
        else
        {
            if(!this.canGoNorth())
            {
                this.score++;
            }
            else
            {
                Robot.coordX--;
                Map.map[Robot.coordX][Robot.coordY] = 2;
            }
        }
    }

    /**
     * Increases the room number by 1 when south button clicked once
     */
    public void sIncrement()
    {
        this.counter++;

        if(this.canGoSouth())
        {
            Robot.coordX++;
            Map.map[Robot.coordX][Robot.coordY] = 2;
        }
        else
        {
            this.score++;
        }
    }

    /**
     * Increases the room number by 1 when west button clicked once
     */
    public void wIncrement()
    {
        this.counter++;

        if(Robot.coordY == 0)
        {
            this.score++;
        }

        if(this.canGoWest())
        {
            Robot.coordY--;
            Map.map[Robot.coordX][Robot.coordY] = 2;
        }
    }

    /**
     * Increases the room number by 1 when east button clicked once
     */
    public void eIncrement()
    {
        this.counter++;

        if(this.canGoEast())
        {
            Robot.coordY++;
            Map.map[Robot.coordX][Robot.coordY] = 2;
        }
        else
        {
            this.score++;
        }
    }

    /**
     * Return the number of room as a String.
     * @return String containing the number of room.
     */
    public String getCounter()
    {
        return String.format("%s", counter);
    }

    public void setCounter()
    {
        this.counter = 0;
    }
}