package ca.com.william.countingrooms;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * The controller of Counting Rooms app.
 *
 * @author Hengchao Xiang
 */
public class CountingRoomsActivity extends AppCompatActivity
{
    private CountingRoomModel countingRoomModel;
    private TextView counterView;
    private EditText roomText;
    private Vibrator vibrator;
    private TextView score;
    int sizeLayout;
    int steps;
    private ColorStateList oldColor;
    private String roomNumString;
    LinearLayout linearLayout;
    Grid grid;

    /**
     * Initializes the controller.
     *
     * @param savedInstanceState information needed for re-initialization
     */
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counting_rooms);  //here this is the name of xml file

        this.countingRoomModel = new CountingRoomModel();
        this.counterView = (TextView) findViewById(R.id.result);
        this.roomText = (EditText) findViewById(R.id.roomText);
        this.vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        this.score = (TextView) findViewById(R.id.scoreView);
        steps = 0;
        oldColor = counterView.getTextColors();
        this.linearLayout = (LinearLayout)findViewById(R.id.grid);
        roomNumString = "";
    }

    public void newClicked(View view)
    {
        if(steps != 0)
        {
            //we can only get the params of views after the create of acitvity is finished.
            this.sizeLayout = linearLayout.getWidth();
            linearLayout.getLayoutParams().height = sizeLayout;
            this.grid = new Grid(sizeLayout, this);
            countingRoomModel = new CountingRoomModel();
            countingRoomModel.setCounter();

            grid.removeRobot(linearLayout);

            roomText.setText("");
            counterView.setText(countingRoomModel.getCounter());
            counterView.setTextColor(oldColor);
            grid.clear();
            roomNumString = "";
            score.setText("0");
            linearLayout.setBackground(Grid.bitmapDrawable);  //here set the Bitmap as the background, it will fit the view if the Bitmap is not big enough
        }
        else
        {
            Toast toast = Toast.makeText(this, "Please play the game first!", Toast.LENGTH_LONG);   //create a Toast object
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
            return;
        }

    }

    public void roomOnclick(View view)
    {
        roomNumString = roomText.getText().toString();
        steps = Integer.parseInt(countingRoomModel.getCounter());

        if(roomNumString.length() != 0  && steps != 0)
        {
            int roomNum = Integer.parseInt(roomNumString);
            this.sizeLayout = linearLayout.getWidth();
            linearLayout.getLayoutParams().height = sizeLayout;
            this.grid = new Grid(sizeLayout, this);

            counterView.setTextColor((this.countingRoomModel.compareRooms(roomNum)) ? Color.rgb(0, 255, 0) : Color.rgb(255, 0, 0));

            linearLayout.setBackground(Grid.bitmapDrawable);  //here set the Bitmap as the background, it will fit the view if the Bitmap is not big enough
            grid.showRobot(Robot.coordY, Robot.coordX, this, linearLayout);
        }
        else
        {
            if(steps != 0)
            {
                Toast toast = Toast.makeText(this, "Please input the room number!", Toast.LENGTH_LONG);   //create a Toast object
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                roomNumString = "";
                return;
            }
            else
            {
                Toast toast = Toast.makeText(this, "Please play the game first!", Toast.LENGTH_LONG);   //create a Toast object
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                roomNumString = "";
                return;
            }
        }
    }

    /**
     * Invokes sIncrement() method and setText() method one time when south button clicked once.
     *
     * @param view not applicable.
     */
    public void north(View view)
    {
        if(!this.countingRoomModel.canGoNorth())
        {
            // Vibrate for 400 milliseconds
            vibrator.vibrate(400);
        }

        this.countingRoomModel.nIncrement();
        score.setText(this.countingRoomModel.getScore());
        this.setText();

        if(roomNumString.length() != 0)
        {
            grid.showRobot(Robot.coordY, Robot.coordX, this, linearLayout);
            grid.draw();
        }
    }

    /**
     * Invokes sIncrement() method and setText() method one time when south button clicked once.
     *
     * @param view not applicable.
     */
    public void south(View view)
    {
        if(!this.countingRoomModel.canGoSouth())
        {
            // Vibrate for 400 milliseconds
            vibrator.vibrate(400);
        }

        this.countingRoomModel.sIncrement();
        score.setText(this.countingRoomModel.getScore());
        this.setText();

        if(roomNumString.length() != 0)
        {
            grid.showRobot(Robot.coordY, Robot.coordX, this, linearLayout);
            grid.draw();
        }
    }

    /**
     * Invokes sIncrement() method and setText() method one time when south button clicked once.
     *
     * @param view not applicable.
     */
    public void west(View view)
    {
        if(!this.countingRoomModel.canGoWest())
        {
            // Vibrate for 400 milliseconds
            vibrator.vibrate(400);
        }

        this.countingRoomModel.wIncrement();
        score.setText(this.countingRoomModel.getScore());
        this.setText();

        if(roomNumString.length() != 0)
        {
            grid.showRobot(Robot.coordY, Robot.coordX, this, linearLayout);
            grid.draw();
        }
    }

    /**
     * Invokes sIncrement() method and setText() method one time when south button clicked once.
     *
     * @param view not applicable.
     */
    public void east(View view)
    {
        if(!this.countingRoomModel.canGoEast())
        {
            // Vibrate for 400 milliseconds
            vibrator.vibrate(400);
        }

        this.countingRoomModel.eIncrement();
        score.setText(this.countingRoomModel.getScore());
        this.setText();

        if(roomNumString.length() != 0)
        {
            grid.showRobot(Robot.coordY, Robot.coordX, this, linearLayout);
            grid.draw();
        }
    }

    /**
     * Sets the text using the value of room number.
     */
    private void setText()
    {
        counterView.setText(this.countingRoomModel.getCounter());
    }
}
