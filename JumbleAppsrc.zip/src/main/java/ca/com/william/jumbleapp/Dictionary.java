package ca.com.william.jumbleapp;

import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * The dictionary, which is the model of this app.
 *
 * @author Franck van Breugel
 */
public class Dictionary
{
    private static ArrayList<String> dictionary;

    /**
     * Initializes this dictionary from the given file.  Each line of the file contains a
     * single word.
     *
     * @param file file containing the words of this dictionary.
     */
    public Dictionary(File file)
    {
        dictionary = new ArrayList<>();

        try
        {
            Scanner input = new Scanner(file);

            while (input.hasNextLine())
            {
                String word = input.nextLine();
                dictionary.add(word);
            }
            input.close();
        }
        catch (FileNotFoundException e)
        {
            // do nothing
        }
    }

    /**
     * Returns the list of words that are unscramblings of the given word.
     *
     * @param word word to be unscrambled.
     * @return list of words that are unscramblings of the given word.
     */
    public List<String> getUnscramblings(String word)
    {
        ArrayList<String> resultList = new ArrayList<>();
        String sortedWord = sort(word);

        for (String string : dictionary)
        {
            if (word.length() == string.length() && sortedWord.equals(sort(string)))
            {
                resultList.add(string);
            }
        }

        return resultList;
    }

    public String sort(String word)
    {
        char[] temp = word.toLowerCase().toCharArray();
        Arrays.sort(temp);
        return String.valueOf(temp);
    }
}
