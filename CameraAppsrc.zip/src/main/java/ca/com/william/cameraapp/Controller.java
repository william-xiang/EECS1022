package ca.com.william.cameraapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;

/**
 * The controller of the camera app.
 *
 * @author Franck van Breugel
 */
public class Controller extends AppCompatActivity
{
    private Bitmap bitmap;
    private Button xReflect, yReflect, rotate, start, scale, reset;
    private EditText degreeText, scaleText;
    private ImageView imageView;
    private String path;

    /**
     * Path to the folder in which the photo is stored.
     */
    private static final String PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/temp/";
    /**
     * Reference to the model of this app.
     */
    private Model image;

    /**
     * Initializes this controller.
     *
     * @param savedInstanceState not applicable.
     */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.activity_controller);

        // make yreflect button invisible
        yReflect = (Button) findViewById(R.id.reflectY);
        xReflect = (Button) findViewById(R.id.reflectX);
        rotate = (Button) findViewById(R.id.rotate);
        start = (Button) findViewById(R.id.start);
        scale = (Button) findViewById(R.id.scale);
        reset = (Button) findViewById(R.id.reset);
        degreeText = (EditText) findViewById(R.id.degree);
        scaleText = (EditText) findViewById(R.id.scaleText);
        imageView = (ImageView) findViewById(R.id.image);
        path = PATH + "sample.jpg";

        yReflect.setVisibility(View.GONE);
        xReflect.setVisibility(View.GONE);
        rotate.setVisibility(View.GONE);
        degreeText.setVisibility(View.GONE);
        scale.setVisibility(View.GONE);
        scaleText.setVisibility(View.GONE);
        reset.setVisibility(View.GONE);

        // create a folder to store the photo
        File file = new File(PATH);
        file.mkdirs();
    }

    /**
     * Start the camera and store the photo.
     *
     * @param view not applicable.
     */
    public void start(View view)
    {
        // create file to store photo
        File file = new File(path);
        try
        {
            file.createNewFile();
        }
        catch (IOException e)
        {
            // do nothing
        }

        // convert file to uri
        Uri uri = Uri.fromFile(file);

        // start camera, and show the camera view using startActivityForResult
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        this.startActivityForResult(cameraIntent, 0);
    }

    /**
     * Reflect along the y-axis.
     *
     * @param view not applicable.
     */
    public void reflectY(View view)
    {
        // update the model
        this.image.reflectY();

        // set photo as image
        imageView.setImageBitmap(this.image.getBitmap());

        Model imageReflectY = new Model(bitmap);
        imageReflectY.reflectY();
        this.bitmap = imageReflectY.getBitmap();
    }

    /**
     * Reflect along the x-axis.
     *
     * @param view not applicable.
     */
    public void reflectX(View view)
    {
        // update the model
        this.image.reflectX();

        // set photo as image
        imageView.setImageBitmap(this.image.getBitmap());

        Model imageReflectX = new Model(bitmap);
        imageReflectX.reflectX();
        this.bitmap = imageReflectX.getBitmap();
    }

    /**
     * Rotate the picture.
     *
     * @param view not applicable.
     */
    public void rotate(View view)
    {
        String degree = degreeText.getText().toString();

        if (degree.equals(""))
        {
            Toast toast = Toast.makeText(this, "Please input the degree!", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
            return;
        }

        //reset bitmap
        this.image.resetBitmap(bitmap);

        this.image.scale("1");

        // update the model
        this.image.rotate(degree);

        // set photo as image
        imageView.setImageBitmap(this.image.getBitmap());
    }

    public void scale(View view)
    {
        String scale = scaleText.getText().toString();

        if (scale.equals("") || scale.equals("00.0") || scale.equals("000.0") || scale.equals("00.00") || Double.parseDouble(scale) == 0)
        {
            String empty = "Please input the scale!";
            String zero = "Please input the scale greater than zero!";
            Toast toast;

            if(scale.equals(""))
            {
                toast = Toast.makeText(this, empty, Toast.LENGTH_SHORT);
            }
            else
            {
                toast = Toast.makeText(this, zero, Toast.LENGTH_SHORT);
            }

            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
            return;
        }

        this.image.resetBitmap(bitmap);
        this.image.rotate("0");

        // update the model
        this.image.scale(scale);

        // set photo as image
        imageView.setImageBitmap(this.image.getBitmap());
    }

    public void reset(View view)
    {
        this.image.resetAlphaScale();
        bitmap = reduceImageSize();
        this.image.resetBitmap(bitmap);
        imageView.setImageBitmap(this.image.getBitmap());
    }

    /**
     * Make the start button invisible, make the x-reflect button visible and display
     * the photo.
     *
     * @param requestCode not applicable.
     * @param resultCode not applicable.
     * @param data not applicable.
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        // make start button invisible
        start.setVisibility(View.GONE);

        // make yreflect button visible
        yReflect.setVisibility(View.VISIBLE);

        // make xreflect button visible
        xReflect.setVisibility(View.VISIBLE);

        // make rotate button visible
        rotate.setVisibility(View.VISIBLE);

        degreeText.setVisibility(View.VISIBLE);
        scaleText.setVisibility(View.VISIBLE);
        scale.setVisibility(View.VISIBLE);
        reset.setVisibility(View.VISIBLE);

        bitmap = reduceImageSize();

        // create model, and use the photo taken to initiate the object, we will use this object in xreflect, yreflect and rotate
        this.image = new Model(bitmap);

        // set photo as image
        imageView.setImageBitmap(image.getBitmap());
    }

    public Bitmap reduceImageSize()
    {
        Bitmap originBitmap = BitmapFactory.decodeFile(path);
        double width = originBitmap.getWidth();
        double height = originBitmap.getHeight();
        final int REQURIED_WIDTH = 400;
        bitmap = Bitmap.createScaledBitmap(BitmapFactory.decodeFile(path), REQURIED_WIDTH, (int)(height / width * REQURIED_WIDTH), false);
        return bitmap;
    }
}
