package ca.com.william.cameraapp;

import android.graphics.Bitmap;

/**
 * The model of the camera app.
 *
 * @author Franck van Breugel
 */
public class Model
{
    private Bitmap bitmap;
    private double alpha;
    private double scale;

    /**
     * Initializes this model with the given bitmap.
     *
     * @param bitmap bitmap of this model.
     */
    public Model(Bitmap bitmap)
    {
        this.bitmap = bitmap;
        this.alpha = 0;
        this.scale = 1;
    }

    /**
     * Returns the bitmap of this model.
     *
     * @return bitmap of this model.
     */
    public Bitmap getBitmap()
    {
        return this.bitmap;
    }

    /**
     * Reflects the bitmap of this model along the y-axis.
     */
    public void reflectY()
    {
        final int WIDTH = this.bitmap.getWidth();
        final int HEIGHT = this.bitmap.getHeight();

        Bitmap reflection = Bitmap.createBitmap(WIDTH, HEIGHT, this.bitmap.getConfig());

        for (int x = 0; x < WIDTH; x++)
        {
            for (int y = 0; y < HEIGHT; y++)
            {
                int color = this.bitmap.getPixel(x, y);
                reflection.setPixel(WIDTH - 1 - x, y, color);
            }
        }

        double alphaEorO = Math.ceil(2 * alpha / Math.PI);

        if(alphaEorO % 2 == 1)
        {
            double theta = 2* (0.5 * Math.PI - this.alpha % (2 * Math.PI)) - Math.PI;
            this.alpha += theta;
        }
        else
        {
            double theta = 2* (this.alpha % (2 * Math.PI) - 0.5 * Math.PI) - Math.PI;
            this.alpha -= theta;
        }

        this.bitmap = reflection;
    }

    /**
     * Reflects the bitmap of this model along the x-axis.
     */
    public void reflectX()
    {
        final int WIDTH = this.bitmap.getWidth();
        final int HEIGHT = this.bitmap.getHeight();

        Bitmap reflection = Bitmap.createBitmap(WIDTH, HEIGHT, this.bitmap.getConfig());

        for (int y = 0; y < HEIGHT; y++)
        {
            for (int x = 0; x < WIDTH; x++)
            {
                int color = this.bitmap.getPixel(x, y);
                reflection.setPixel(x, HEIGHT - 1 - y, color);  //pixel is from 0, so it's 1 less than width
            }
        }

        double alphaEorO = Math.ceil(2 * alpha / Math.PI);

        if(alphaEorO % 2 == 1)
        {
            double theta = 2 * (this.alpha % (2 * Math.PI));
            this.alpha -= theta;
        }
        else
        {
            double theta = 2* (Math.PI - this.alpha % (2 * Math.PI));
            this.alpha += theta;
        }

        this.bitmap = reflection;
    }

    /**
     * Reflects the bitmap of this model along the x-axis.
     */
    public void rotate(String degreeStr)
    {
        final int WIDTH = bitmap.getWidth();
        final int HEIGHT = bitmap.getHeight();
        this.alpha += Math.PI * Double.parseDouble(degreeStr) / 180;

        Bitmap reflection = Bitmap.createBitmap(getBitmapSize(WIDTH, HEIGHT)[0], getBitmapSize(WIDTH,HEIGHT)[1], bitmap.getConfig());

        for (int x = 0; x < WIDTH; x++)
        {
            for (int y = 0; y < HEIGHT; y++)
            {
                int color = bitmap.getPixel(x, y);
                int xRotated = (int)Math.round(Math.cos(alpha) * (x - (double)(WIDTH - 1) / 2) - Math.sin(alpha) * (y - (double)(HEIGHT - 1) / 2) + (double)(WIDTH - 1) / 2 - getBitmapSize(WIDTH, HEIGHT)[2]);
                int yRotated = (int)Math.round(Math.sin(alpha) * (x - (double)(WIDTH - 1) / 2) + Math.cos(alpha) * (y - (double)(HEIGHT - 1) / 2) + (double)(HEIGHT - 1) / 2 - getBitmapSize(WIDTH, HEIGHT)[3]);

                reflection.setPixel(xRotated, yRotated, color);
            }
        }

        this.bitmap = reflection;
    }

    public void scale(String scaleStr)
    {
        final int WIDTH = this.bitmap.getWidth();
        final int HEIGHT = this.bitmap.getHeight();
        this.scale *= Double.parseDouble(scaleStr);
        Bitmap reflection;

        if(scale < 1)
        {
            reflection = Bitmap.createBitmap(WIDTH, HEIGHT, this.bitmap.getConfig());

            for (int y = 0; y < HEIGHT; y++)
            {
                for (int x = 0; x < WIDTH; x++)
                {
                    int color = this.bitmap.getPixel(x, y);
                    reflection.setPixel((int)(x * scale + WIDTH / 2 - WIDTH * scale / 2), (int)(y * scale + HEIGHT / 2 - HEIGHT * scale / 2), color);  //pixel is from 0, so it's 1 less than width
                }
            }

            this.bitmap = reflection;
        }
        else if(scale >= 1)
        {
            if (WIDTH * scale <= WIDTH && HEIGHT * scale <= HEIGHT)
            {
                reflection = Bitmap.createBitmap((int)(WIDTH * scale), (int)(HEIGHT * scale), this.bitmap.getConfig());

                for (int y = 0; y < HEIGHT; y++)
                {
                    for (int x = 0; x < WIDTH; x++)
                    {
                        int color = this.bitmap.getPixel(x, y);
                        reflection.setPixel((int)(x * scale), (int)(y * scale), color);  //pixel is from 0, so it's 1 less than width
                    }
                }

                this.bitmap = reflection;
            }
            else
            {
                reflection = Bitmap.createBitmap(WIDTH, HEIGHT, this.bitmap.getConfig());

                for (int y = 0; y < HEIGHT; y++)
                {
                    for (int x = 0; x < WIDTH; x++)
                    {
                        int color = this.bitmap.getPixel(x, y);
                        int xScaled = (int)(x * scale - WIDTH * (scale - 1) / 2);
                        int yScaled = (int)(y * scale - HEIGHT * (scale - 1) / 2);

                        if(xScaled >= 0 && yScaled >= 0 && xScaled < WIDTH && yScaled < HEIGHT)
                        {
                            reflection.setPixel(xScaled, yScaled, color);  //pixel is from 0, so it's 1 less than width
                        }
                    }
                }

                this.bitmap = reflection;
            }
        }
    }

    public void resetBitmap(Bitmap bm)
    {
        this.bitmap = bm;
    }

    public int[] getBitmapSize(int WIDTH, int HEIGHT)
    {
        int coord[][] = new int[4][2];
        int coordOrigin[][] = {{0, 0}, {WIDTH - 1, 0}, {WIDTH - 1, HEIGHT - 1}, {0, HEIGHT - 1}};

        for(int i = 0; i < 4; i++)
        {
            coord[i][0] = (int)Math.round(Math.cos(alpha) * (coordOrigin[i][0] - (double)(WIDTH - 1) / 2) - Math.sin(alpha) * (coordOrigin[i][1] - (double)(HEIGHT - 1) / 2) + (double)(WIDTH - 1) / 2);
            coord[i][1] = (int)Math.round((Math.sin(alpha) * (coordOrigin[i][0] - (double)(WIDTH - 1) / 2) + Math.cos(alpha) * (coordOrigin[i][1] - (double)(HEIGHT - 1) / 2) + (double)(HEIGHT - 1) / 2));
        }

        int minX = coord[0][0], minY = coord[0][1], maxX = coord[0][0], maxY = coord[0][1];

        for (int i = 1; i < 4; i++)
        {
            minX = (minX < coord[i][0]) ? minX : coord[i][0];
            minY = (minY < coord[i][1]) ? minY : coord[i][1];
            maxX = (maxX > coord[i][0]) ? maxX : coord[i][0];
            maxY = (maxY > coord[i][1]) ? maxY : coord[i][1];
        }

        int bitmapWidth = maxX - minX + 1;
        int bitmapHeight = maxY - minY + 1;
        int bitmapSize[] = {bitmapWidth, bitmapHeight, minX, minY};
        return bitmapSize;
    }

    public void resetAlphaScale()
    {
        this.alpha = 0;
        this.scale = 1;
    }
}
