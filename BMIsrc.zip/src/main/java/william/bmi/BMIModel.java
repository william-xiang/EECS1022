package william.bmi;

import java.io.PrintStream;
import java.util.Scanner;

public class BMIModel
{
    private double weight;
    private double height;

    public BMIModel(String w, String h)  //constructor
    {
        this.weight = Double.parseDouble(w);
        this.height = Double.parseDouble(h);
    }

    public String getBMI()
    {
        double index = this.weight / (this.height * this.height);
        String result = String.format("%.1f", index);    //%.1f means that 1 decimal float
        return result;
    }

    public static void main(String[] args) {
        BMIModel model = new BMIModel("56", "1.6");

        System.out.println(model.getBMI());
        System.out.println(56/1.6/1.6);
    }
}
