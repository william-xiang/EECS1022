package william.bmi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class BMIActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);
    }

    public void buttonClicked(View v)
    {
        String weight = ((EditText) findViewById(R.id.weightBox)).getText().toString();
        String height = ((EditText) findViewById(R.id.heightBox)).getText().toString();

        BMIModel model = new BMIModel(weight, height);
        String answer = model.getBMI();

        ((TextView)findViewById(R.id.answer)).setText(answer);
    }
}
