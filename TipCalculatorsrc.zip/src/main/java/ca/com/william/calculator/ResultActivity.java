package ca.com.william.calculator;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class ResultActivity extends Activity implements View.OnClickListener{
    private SeekBar seekBar;
    private Button button10P, button15P, button20P, roundUp, roundDown, splitBill;
    private TextView subTotalView,tipView, totalView;
    private String input;
    private static Double subTotal, tip, total;
    private int percentage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        button10P = findViewById(R.id.button10P);
        button15P = findViewById(R.id.button15P);
        button20P = findViewById(R.id.button20P);
        roundUp = findViewById(R.id.buttonRUp);
        roundDown = findViewById(R.id.buttonRDown);
        splitBill = findViewById(R.id.splitBill);
        seekBar = findViewById(R.id.seekBar);
        percentage = 15;
        subTotalView = findViewById(R.id.subtotalEdit);
        tipView = findViewById(R.id.tipEdit);
        totalView = findViewById(R.id.totalEdit);
        input = EnterAcivity.getInput();
        subTotal = Double.parseDouble(input);
        tip = subTotal * percentage / 100.0;
        total = subTotal + tip;

        setSeekBar();
        button10P.setOnClickListener(this);
        button15P.setOnClickListener(this);
        button20P.setOnClickListener(this);
        roundUp.setOnClickListener(this);
        roundDown.setOnClickListener(this);
        splitBill.setOnClickListener(this);
        subTotalView.setText(String.format("$%s", input));
        tipView.setText(String.format("$%.2f", tip));
        totalView.setText(String.format("$%.2f", total));
    }

    /**
     * Updates the tip and total amount according to the progress of seekbar using OnSeekBarChangeListener class
     */
    public void setSeekBar()
    {
        final TextView progress = findViewById(R.id.tipView);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                percentage = i;
                tip = subTotal * percentage / 100.0;
                total = subTotal + tip;
                tipView.setText(String.format("$%.2f", tip));
                totalView.setText(String.format("$%.2f", total));
                progress.setText(String.format("Tip(%s%%):", i));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    @Override
    /**
     * Implements the onClick() method in OnClickListener class
     */
    public void onClick(View view)
    {
        if(view.getId() == R.id.splitBill)
        {
            Intent intent = new Intent(this, SplitBillActivity.class);
            startActivity(intent);
        }
        else
        {
            switch(view.getId())
            {
                case R.id.button10P:
                    percentage = 10;
                    break;

                case R.id.button15P:
                    percentage = 15;
                    break;

                case R.id.button20P:
                    percentage = 20;
                    break;

                case R.id.buttonRUp:
                    total = Math.ceil(total);
                    break;

                case R.id.buttonRDown:
                    total = Math.floor(total);
                    break;

                default:
                    break;
            }

            seekBar.setProgress(percentage);
            tip = subTotal * percentage / 100.0;
            total = subTotal + tip;

            switch(view.getId())
            {
                case R.id.buttonRUp:
                    total = Math.ceil(total);
                    tip = total - subTotal;
                    break;

                case R.id.buttonRDown:
                    total = Math.floor(total);
                    tip = total - subTotal;
                    break;

                default:
                    break;
            }

            tipView.setText(String.format("$%.2f", tip));
            totalView.setText(String.format("$%.2f", total));
        }
    }

    /**
     * Returns subtotal
     * @return subtotal
     */
    public static double getSubTotal()
    {
        return subTotal;
    }

    /**
     * Returns tip
     * @return tip
     */
    public static double getTip()
    {
        return tip;
    }

    /**
     * Returns total
     * @return total
     */
    public static double getTotal()
    {
        return total;
    }
}
