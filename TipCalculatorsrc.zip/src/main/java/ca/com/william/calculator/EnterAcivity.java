package ca.com.william.calculator;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class EnterAcivity extends Activity implements View.OnClickListener {
    private Button button0, button1, button2, button3, button4, button5, button6, button7, button8, button9, buttonOk, buttonDel;
    private TextView outputView;
    private static String input;
    private EnterModel enterModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter);
        button0 = findViewById(R.id.button0);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);
        buttonOk = findViewById(R.id.buttonOk);
        buttonDel = findViewById(R.id.buttonDel);
        outputView = findViewById(R.id.outputView);
        input = "0.00";
        enterModel = new EnterModel();


        button0.setOnClickListener(this);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        button6.setOnClickListener(this);
        button7.setOnClickListener(this);
        button8.setOnClickListener(this);
        button9.setOnClickListener(this);
        buttonOk.setOnClickListener(this);
        buttonDel.setOnClickListener(this);
        outputView.setText("$" + input);
    }

    @Override
    /**
     * impliments onClick() method in OnClickListener class
     */
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.buttonOk:
                if (input.equals("0.00"))
                {
                    Toast toast = Toast.makeText(this, "Please Input Bill Amount!", Toast.LENGTH_LONG);   //create a Toast object
                    toast.setGravity(Gravity.CENTER, 0, 0);   //set Gravity of the toast
                    toast.show();  //show the content of the toast
                }
                else
                {
                    Intent intent = new Intent(this, ResultActivity.class);
                    startActivity(intent);
                }
                break;

            case R.id.buttonDel:
                input = enterModel.del(input);
                break;

            case R.id.button0:
                if(!input.equals("0.00"))
                    input = enterModel.intputChange(input, 0);
                break;

            case R.id.button1:
                input = enterModel.intputChange(input, 1);
                break;

            case R.id.button2:
                input = enterModel.intputChange(input, 2);
                break;

            case R.id.button3:
                input = enterModel.intputChange(input, 3);
                break;

            case R.id.button4:
                input = enterModel.intputChange(input, 4);
                break;

            case R.id.button5:
                input = enterModel.intputChange(input, 5);
                break;

            case R.id.button6:
                input = enterModel.intputChange(input, 6);
                break;

            case R.id.button7:
                input = enterModel.intputChange(input, 7);
                break;

            case R.id.button8:
                input = enterModel.intputChange(input, 8);
                break;

            case R.id.button9:
                input = enterModel.intputChange(input, 9);
                break;

            default:
                break;
        }
        outputView.setText("$" + input);
    }

    /**
     * Gets the number showed in the textview of format string
     * @return a string of a number inputed in the textview
     */
    public static String getInput()
    {
        return input;
    }
}
