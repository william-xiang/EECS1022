package ca.com.william.calculator;

/**
 * Model of EnterActivity
 */
public class EnterModel
{
    /**
     * Changes the input according the button pressed
     * @param input the string showed in the textview before the button pressed
     * @param number the number on the button pressed
     * @return the new string of number after the button pressed
     */
    public String intputChange(String input, int number)
    {
        String output = "";

        if(input.startsWith("0") && input.length() <= 12)
        {
            for(int i = 0; i < input.length(); i++)
            {
                switch (i)
                {
                    case 0:
                        output += input.charAt(2);
                        break;
                    case 1:
                        output += ".";
                        break;
                    case 2:
                        output += input.charAt(3);
                        break;
                    default:
                        output += number;
                        break;
                }
            }
            return output;
        }
        else if(input.length() <= 12)
        {
            int length = input.length();

            for(int i = 0; i < length + 1; i++)
            {
                if(i == length)
                {
                    output += number;
                }
                else if(i == length - 2)
                {
                    output += ".";
                }
                else if(i == length - 3)
                {
                    output += input.charAt(length - 2);
                }
                else
                {
                    output += input.charAt(i);
                }
            }
            return output;
        }
        else
        {
            return input;
        }
    }

    /**
     * Deletes the last digit of number showed in textview after del button pressed
     * @param input the string showed in the textview before the button pressed
     * @return the new string of number after the last digit of number removed
     */
    public String del(String input)
    {
        int length = input.length();
        String output = "";

        if(length == 4)
        {
            for(int i = 0; i < input.length(); i++)
            {
                switch (i)
                {
                    case 0:
                        output += 0;
                        break;
                    case 1:
                        output += ".";
                        break;
                    case 2:
                        output += input.charAt(0);
                        break;
                    default:
                        output += input.charAt(2);
                        break;
                }
            }
            return output;
        }
        else
        {
            for(int i = 0; i < length - 1; i++)
            {
                if(i == length - 3)
                {
                    output += input.charAt(length - 4);
                }
                else if(i == length - 4)
                {
                    output += ".";
                }
                else
                {
                    output += input.charAt(i);
                }
            }
            return output;
        }
    }
}
