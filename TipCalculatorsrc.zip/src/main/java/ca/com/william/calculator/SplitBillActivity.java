package ca.com.william.calculator;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.math.RoundingMode;
import java.text.NumberFormat;

public class SplitBillActivity extends Activity implements View.OnClickListener
{
    private double subTotal, tip, total, adjustment;
    private int number;
    private TextView subTotalView, tipView, totalView, adjustmentView, numberView;
    private Button buttonDec, buttonInc;
    private NumberFormat fmtCeiling, fmtFloor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_split_bill);
        number = 2;
        subTotalView = findViewById(R.id.subtotalEdit);
        tipView = findViewById(R.id.tipEdit);
        totalView = findViewById(R.id.totalEdit);
        adjustmentView = findViewById(R.id.adjustmentEdit);
        buttonDec = findViewById(R.id.buttonDec);
        buttonInc = findViewById(R.id.buttonInc);
        numberView = findViewById(R.id.numberEdit);

        fmtCeiling = NumberFormat.getNumberInstance();
        fmtCeiling.setMaximumFractionDigits(2);
        fmtCeiling.setRoundingMode(RoundingMode.CEILING);

        fmtFloor = NumberFormat.getNumberInstance();
        fmtFloor.setMaximumFractionDigits(2);
        fmtFloor.setRoundingMode(RoundingMode.FLOOR);

        buttonDec.setOnClickListener(this);
        buttonInc.setOnClickListener(this);
        setText();
    }

    @Override
    /**
     * Implements the onClick() method in OnClickListener class
     */
    public void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.buttonDec:
                if(number > 2)
                    number--;
                break;

            case R.id.buttonInc:
                number++;
        }
        setText();
    }

    /**
     * Sets text of subTotalView, tipView, totalView, adjustmentView and numberView
     */
    public void setText()
    {
        subTotal = Double.parseDouble(fmtFloor.format(ResultActivity.getSubTotal() / number));
        tip = Double.parseDouble(fmtFloor.format(ResultActivity.getTip() / number));
        total = Double.parseDouble(fmtCeiling.format(ResultActivity.getTotal() /number));
        adjustment = total - subTotal - tip;

        subTotalView.setText(String.format("$%.2f", subTotal));
        tipView.setText(String.format("$%.2f", tip));
        totalView.setText(String.format("$%.2f", total));
        adjustmentView.setText(String.format("$%.2f", adjustment >= 0 ? adjustment : - adjustment));
        numberView.setText(String.format("%s", number));
    }
}
